/*
 Navicat Premium Data Transfer

 Source Server         : 跳蚤项目（120.79.84.114 -docker-Mysql8.0）
 Source Server Type    : MySQL
 Source Server Version : 80200 (8.2.0)
 Source Host           : 120.79.84.114:9989
 Source Schema         : com9n1m_mall_content

 Target Server Type    : MySQL
 Target Server Version : 80200 (8.2.0)
 File Encoding         : 65001

 Date: 11/01/2024 11:35:27
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for biz_args_config
-- ----------------------------
DROP TABLE IF EXISTS `biz_args_config`;
CREATE TABLE `biz_args_config` (
  `config_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '配置id',
  `config_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '配置名称',
  `config_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '配置key值',
  `config_value` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '配置value值',
  `config_value_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '配置value的数据类型',
  `remarks` varchar(1024) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  `create_time` datetime(6) NOT NULL COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`config_id`) USING BTREE,
  UNIQUE KEY `idx_biz_args_config_key` (`config_key`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='系统业务参数配置';

-- ----------------------------
-- Records of biz_args_config
-- ----------------------------
BEGIN;
INSERT INTO `biz_args_config` (`config_id`, `config_name`, `config_key`, `config_value`, `config_value_type`, `remarks`, `create_time`, `update_time`) VALUES ('30010', '订单自动确认收货时间', 'ORDER_AUTO_RECEIVE_TIME', '30', 'TYPE_INTEGER', '单位分钟', '2023-05-16 17:54:02.000000', '2023-05-16 17:54:04.000000');
INSERT INTO `biz_args_config` (`config_id`, `config_name`, `config_key`, `config_value`, `config_value_type`, `remarks`, `create_time`, `update_time`) VALUES ('30020', '订单自动取消时间', 'ORDER_CANCEL_ORDER_TIME', '30', 'TYPE_INTEGER', '单位分钟', '2023-05-16 17:54:39.000000', '2023-05-17 14:57:47.000000');
INSERT INTO `biz_args_config` (`config_id`, `config_name`, `config_key`, `config_value`, `config_value_type`, `remarks`, `create_time`, `update_time`) VALUES ('30030', '订单自动结算时间', 'ORDER_SEPARATE_ACCOUNT_TIME', '3', 'TYPE_INTEGER', '单位分钟', '2023-05-16 17:55:15.000000', '2023-05-16 17:55:16.000000');
INSERT INTO `biz_args_config` (`config_id`, `config_name`, `config_key`, `config_value`, `config_value_type`, `remarks`, `create_time`, `update_time`) VALUES ('30040', '售后自动审核通过-已支付未发货状态', 'AFTER_SALE_AUTO_AUDIT_PAYED', '1', 'TYPE_INTEGER', '单位分钟', '2023-05-16 17:56:59.000000', '2023-05-16 17:57:01.000000');
INSERT INTO `biz_args_config` (`config_id`, `config_name`, `config_key`, `config_value`, `config_value_type`, `remarks`, `create_time`, `update_time`) VALUES ('30041', '售后自动审核通过-已发货状态', 'AFTER_SALE_AUTO_AUDIT_SENT', '10', 'TYPE_INTEGER', '单位分钟', '2023-05-16 17:57:38.000000', '2023-05-16 17:57:39.000000');
INSERT INTO `biz_args_config` (`config_id`, `config_name`, `config_key`, `config_value`, `config_value_type`, `remarks`, `create_time`, `update_time`) VALUES ('30050', '售后自动关闭-等待用户发货状态', 'AFTER_SALE_AUTO_CLOSE_WAIT_SEND', '5', 'TYPE_INTEGER', '单位分钟', '2023-05-16 17:58:20.000000', '2023-05-16 17:58:21.000000');
INSERT INTO `biz_args_config` (`config_id`, `config_name`, `config_key`, `config_value`, `config_value_type`, `remarks`, `create_time`, `update_time`) VALUES ('30051', '售后自动关闭-审核拒绝状态 ', 'AFTER_SALE_AUTO_CLOSE_AUDIT_REJECT', '10', 'TYPE_INTEGER', '单位分钟', '2023-05-16 17:59:21.000000', '2023-05-16 17:59:22.000000');
INSERT INTO `biz_args_config` (`config_id`, `config_name`, `config_key`, `config_value`, `config_value_type`, `remarks`, `create_time`, `update_time`) VALUES ('30052', '售后自动关闭-商家拒绝收货状态', 'AFTER_SALE_AUTO_CLOSE_RECEIVE_REJECT', '15', 'TYPE_INTEGER', '单位分钟', '2023-05-16 17:59:47.000000', '2023-05-16 17:59:48.000000');
INSERT INTO `biz_args_config` (`config_id`, `config_name`, `config_key`, `config_value`, `config_value_type`, `remarks`, `create_time`, `update_time`) VALUES ('30060', '售后自动确认收货-等待收货状态', 'AFTER_SALE_AUTO_CONFIRM_RECEIVE_WAIT_RECEIVE', '5', 'TYPE_INTEGER', '单位分钟', '2023-05-16 18:00:06.000000', '2023-05-16 18:00:07.000000');
INSERT INTO `biz_args_config` (`config_id`, `config_name`, `config_key`, `config_value`, `config_value_type`, `remarks`, `create_time`, `update_time`) VALUES ('40010', '快递查询间隔', 'KD_QUERY_INTERVAL', '1800000', 'TYPE_INTEGER', '', '2023-05-16 18:01:06.000000', '2023-05-16 18:01:07.000000');
COMMIT;

-- ----------------------------
-- Table structure for goods_comment
-- ----------------------------
DROP TABLE IF EXISTS `goods_comment`;
CREATE TABLE `goods_comment` (
  `goods_comment_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品评价ID',
  `goods_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '主商品ID',
  `sku_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品SKU ID',
  `goods_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品名称',
  `sku_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'SKU名称',
  `order_main_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '主订单ID',
  `order_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '订单ID',
  `order_detail_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '订单详情ID',
  `brand_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '品牌ID',
  `brand_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '品牌名称',
  `tenant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '租户ID',
  `tenant_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '租户名称',
  `store_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '店铺ID',
  `store_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '店铺名称',
  `member_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '成员ID',
  `member_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '成员名称',
  `phone_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '成员手机号',
  `member_avatar_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '成员头像',
  `goods_comment_grade` int DEFAULT NULL COMMENT '商品评价等级(1-非常差, 2-差, 3-一般, 4-好, 5-非常好)',
  `logistics_comment_grade` int DEFAULT NULL COMMENT '物流评价等级(1-非常差, 2-差, 3-一般, 4-好, 5-非常好)',
  `serve_comment_grade` int DEFAULT NULL COMMENT '服务评价等级(1-非常差, 2-差, 3-一般, 4-好, 5-非常好)',
  `goods_comment_des` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品评价描述(FINE-好评, MEDIUM-中评, LOW-差评)',
  `comment_content` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品评价内容',
  `comment_picture_urls` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品评价图片(多张用英文逗号分割)',
  `comment_video_url` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品评价视频',
  `reply_quantity` int DEFAULT '0' COMMENT '回复次数',
  `reply_last_time` datetime DEFAULT NULL COMMENT '最后回复时间',
  `is_comment_state` tinyint(1) DEFAULT '1' COMMENT '展示状态(0下架 1上架)',
  `comment_remark` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  `comment_src` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '评价来源(MEM-消费者提交评价, SYS-系统自动评价)',
  `is_hide_member` tinyint(1) DEFAULT '0' COMMENT '是否匿名',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`goods_comment_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='商品评价表';

-- ----------------------------
-- Records of goods_comment
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_comment_reply
-- ----------------------------
DROP TABLE IF EXISTS `goods_comment_reply`;
CREATE TABLE `goods_comment_reply` (
  `goods_reply_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '评价回复ID',
  `goods_comment_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品评价ID',
  `reply_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '回复类型(BUYER-消费者互回, SELLER-商家回复, PLATFORM-平台回复, APPEND-消费者追评)',
  `reply_member_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '回复者ID(消费者member_id, 商家merchant_id, 平台admin_id)',
  `reply_member_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '回复者名称(消费者member_name, 商家merchant_name, 平台admin_login_name)',
  `reply_member_avatar_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '回复者头像',
  `reply_content` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '评论回复内容',
  `reply_picture_urls` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '评论回复图片',
  `reply_video_url` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '评论回复视频',
  `src_reply_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT '0' COMMENT '被互回的回复ID',
  `is_reply_state` tinyint(1) DEFAULT '1' COMMENT '展示状态(0下架 1上架)',
  `reply_remark` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  `create_time` datetime(6) DEFAULT NULL COMMENT '创建时间',
  `update_time` datetime(6) DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`goods_reply_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='商品评价回复表';

-- ----------------------------
-- Records of goods_comment_reply
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for mall_banner
-- ----------------------------
DROP TABLE IF EXISTS `mall_banner`;
CREATE TABLE `mall_banner` (
  `mall_banner_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '轮播图ID',
  `banner_url` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '轮播图URL',
  `banner_title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '轮播图标题',
  `banner_location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '轮播图位置(首页配置-HOME_PAGE)',
  `action_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '点击动作类型 (NONE-无 GOODS_DETAIL-商品详情 GOODS_CATEGORY-商品分类)',
  `action_value` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '点击动作目标值',
  `sort_value` bigint NOT NULL DEFAULT '0' COMMENT '排序值',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否展示',
  `file_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'IMAGE' COMMENT '文件类型: 图片；IMAGE、视频；VIDEO',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`mall_banner_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商城配置-轮播图表';

-- ----------------------------
-- Records of mall_banner
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for mall_page
-- ----------------------------
DROP TABLE IF EXISTS `mall_page`;
CREATE TABLE `mall_page` (
  `mall_page_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '页面ID',
  `page_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '页面名称',
  `page_location` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '页面位置(首页配置-HOME_PAGE)',
  `sort_value` bigint NOT NULL DEFAULT '0' COMMENT '排序值',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否展示',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`mall_page_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商城配置-页面表';

-- ----------------------------
-- Records of mall_page
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for mall_page_component
-- ----------------------------
DROP TABLE IF EXISTS `mall_page_component`;
CREATE TABLE `mall_page_component` (
  `mall_page_component_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '组件ID',
  `mall_page_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '页面ID',
  `component_title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '组件标题',
  `component_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '组件类型：轮播图-BANNER、导航位-NAVIGATION_BIT、单列商品列表-SINGLE_GOODS_LIST、双列商品列表-DOUBLE_GOODS_LIST',
  `component_data` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '组件的配置数据',
  `sort_value` bigint NOT NULL DEFAULT '0' COMMENT '排序值',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`mall_page_component_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商城配置-页面组件表';

-- ----------------------------
-- Records of mall_page_component
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for mall_page_item
-- ----------------------------
DROP TABLE IF EXISTS `mall_page_item`;
CREATE TABLE `mall_page_item` (
  `mall_page_item_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '项ID',
  `mall_page_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '页面ID',
  `mall_page_component_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '组件ID',
  `item_type` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '项类型',
  `item_value` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '项配置数据',
  `sort_value` bigint NOT NULL DEFAULT '0' COMMENT '排序值',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`mall_page_item_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商城配置-页面组件元素表';

-- ----------------------------
-- Records of mall_page_item
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for member_behavior
-- ----------------------------
DROP TABLE IF EXISTS `member_behavior`;
CREATE TABLE `member_behavior` (
  `behavior_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '行为ID',
  `member_id` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '用户ID',
  `source_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '来源ID',
  `source_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '来源类型',
  `source_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '来源ID名称',
  `source_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '来源ID手机号',
  `behavior` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '行为（收藏）',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`behavior_id`),
  KEY `idx_member_behavior_source_id` (`source_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户行为表';

-- ----------------------------
-- Records of member_behavior
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for store_banner
-- ----------------------------
DROP TABLE IF EXISTS `store_banner`;
CREATE TABLE `store_banner` (
  `store_banner_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '轮播图ID',
  `tenant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '租户ID',
  `store_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺ID',
  `banner_url` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '轮播图URL',
  `action_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '点击动作类型 (NONE-无 GOODS_DETAIL-商品详情 GOODS_CATEGORY-商品分类)',
  `action_value` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '点击动作目标值',
  `sort_value` bigint NOT NULL DEFAULT '0' COMMENT '排序值',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否展示',
  `file_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'IMAGE' COMMENT '文件类型: 图片；IMAGE、视频；VIDEO',
  `banner_title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '轮播图标题',
  `banner_location` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '轮播图位置(首页配置-HOME_PAGE)',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`store_banner_id`) USING BTREE,
  KEY `idx_store_banner_store_id` (`store_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='店铺配置-轮播图表';

-- ----------------------------
-- Records of store_banner
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for store_page
-- ----------------------------
DROP TABLE IF EXISTS `store_page`;
CREATE TABLE `store_page` (
  `store_page_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '页面ID',
  `tenant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '租户ID',
  `store_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺ID',
  `page_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '页面名称',
  `page_location` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '页面位置(首页配置-HOME_PAGE)',
  `sort_value` bigint NOT NULL DEFAULT '0' COMMENT '排序值',
  `is_show` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否展示',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`store_page_id`) USING BTREE,
  KEY `idx_store_page_store_id` (`store_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='店铺配置-页面表';

-- ----------------------------
-- Records of store_page
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for store_page_component
-- ----------------------------
DROP TABLE IF EXISTS `store_page_component`;
CREATE TABLE `store_page_component` (
  `store_page_component_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '组件ID',
  `tenant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '租户ID',
  `store_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺ID',
  `store_page_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '页面ID',
  `component_title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '组件标题',
  `component_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '组件类型：轮播图-BANNER、导航位-NAVIGATION_BIT、单列商品列表-SINGLE_GOODS_LIST、双列商品列表-DOUBLE_GOODS_LIST',
  `component_data` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '组件的配置数据',
  `sort_value` bigint NOT NULL DEFAULT '0' COMMENT '排序值',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`store_page_component_id`) USING BTREE,
  KEY `idx_store_page_component_store_page_id` (`store_id`,`store_page_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='店铺配置-页面组件表';

-- ----------------------------
-- Records of store_page_component
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for store_page_item
-- ----------------------------
DROP TABLE IF EXISTS `store_page_item`;
CREATE TABLE `store_page_item` (
  `store_page_item_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '项ID',
  `tenant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '租户ID',
  `store_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺ID',
  `store_page_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '页面ID',
  `store_page_component_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '组件ID',
  `item_value` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '项配置数据',
  `item_type` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '项类型',
  `sort_value` bigint NOT NULL DEFAULT '0' COMMENT '排序值',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`store_page_item_id`) USING BTREE,
  KEY `idx_store_page_item_store_page_component_id` (`store_id`,`store_page_id`,`store_page_component_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='店铺配置-页面组件元素表';

-- ----------------------------
-- Records of store_page_item
-- ----------------------------
BEGIN;
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
