/*
 Navicat Premium Data Transfer

 Source Server         : 跳蚤项目（120.79.84.114 -docker-Mysql8.0）
 Source Server Type    : MySQL
 Source Server Version : 80200 (8.2.0)
 Source Host           : 120.79.84.114:9989
 Source Schema         : com9n1m_mall_members

 Target Server Type    : MySQL
 Target Server Version : 80200 (8.2.0)
 File Encoding         : 65001

 Date: 11/01/2024 11:35:51
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for member_address
-- ----------------------------
DROP TABLE IF EXISTS `member_address`;
CREATE TABLE `member_address` (
  `address_id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '收货地址ID',
  `member_id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户ID',
  `address_consignee` varchar(45) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '收件人',
  `gender` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '性别（0-未知  1-男  2-女）',
  `address_phone` char(11) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '收件人联系电话',
  `address_post_code` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '收件人邮编',
  `address_province` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '收获地址省份',
  `province_code` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '省编码',
  `address_city` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '收获地址城市',
  `city_code` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '市编码',
  `address_area` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '收获地址行政区',
  `area_code` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '区/县编码',
  `address_street` varchar(32) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '收获地址街道',
  `address_detail` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '详细地址',
  `is_default` tinyint(1) DEFAULT '0' COMMENT '是否为默认地址：0不是，1是',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`address_id`),
  KEY `idx_member_address_member_id` (`member_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户收货地址表';

-- ----------------------------
-- Table structure for member_assets
-- ----------------------------
DROP TABLE IF EXISTS `member_assets`;
CREATE TABLE `member_assets` (
  `assets_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '钱包ID',
  `member_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '成员ID',
  `wallet_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '钱包类型',
  `coin_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '资产类型',
  `balance` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `balance_usage` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '可用余额',
  `balance_block` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '冻结余额',
  `total_in` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '总流入',
  `total_out` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '总流出',
  `assets_password` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '钱包密码（密文）',
  `assets_password_salt` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '钱包密码-盐',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`assets_id`) USING BTREE,
  UNIQUE KEY `idx_member_assets_uni` (`member_id`,`wallet_type`,`coin_type`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户资产表';

-- ----------------------------
-- Table structure for member_assets_log
-- ----------------------------
DROP TABLE IF EXISTS `member_assets_log`;
CREATE TABLE `member_assets_log` (
  `assets_log_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '钱包流水ID',
  `assets_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '资产ID',
  `member_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '成员ID',
  `wallet_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '钱包类型',
  `coin_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '资产类型',
  `trans_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '业务交易ID',
  `trans_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '交易类型',
  `trans_direction` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '交易方向(IN-流入,OUT-流出)',
  `balance` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `balance_usage` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '可用余额',
  `balance_block` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '冻结余额',
  `trans_amount` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '流水金额',
  `total_in` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '总流入',
  `total_out` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '总流程',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`assets_log_id`) USING BTREE,
  UNIQUE KEY `idx_member_assets_log_uni` (`assets_id`,`member_id`,`wallet_type`,`coin_type`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='资产流水';

-- ----------------------------
-- Table structure for member_footprint
-- ----------------------------
DROP TABLE IF EXISTS `member_footprint`;
CREATE TABLE `member_footprint` (
  `footprint_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '足迹ID',
  `member_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户ID',
  `source_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '来源ID',
  `footprint_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '足迹类型',
  `history_price` decimal(12,2) DEFAULT NULL COMMENT '历史价格',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`footprint_id`) USING BTREE,
  KEY `idx_member_footprint_member_id` (`member_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户足迹表';

-- ----------------------------
-- Table structure for member_info
-- ----------------------------
DROP TABLE IF EXISTS `member_info`;
CREATE TABLE `member_info` (
  `member_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户ID',
  `member_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '用户名字',
  `member_avatar_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '用户头像',
  `phone_number` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '手机号码',
  `gender` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '性别（0-未知  1-男  2-女）',
  `source_id` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '来源ID',
  `source_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'COM9N1M' COMMENT '来源类型(COM9N1M)',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '修改时间',
  PRIMARY KEY (`member_id`) USING BTREE,
  UNIQUE KEY `idx_member_info_member_name` (`member_name`) USING BTREE,
  KEY `idx_member_info_phone_number` (`phone_number`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='用户信息表';

SET FOREIGN_KEY_CHECKS = 1;
