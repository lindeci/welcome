/*
 Navicat Premium Data Transfer

 Source Server         : 跳蚤项目（120.79.84.114 -docker-Mysql8.0）
 Source Server Type    : MySQL
 Source Server Version : 80200 (8.2.0)
 Source Host           : 120.79.84.114:9989
 Source Schema         : com9n1m_mall_promotion

 Target Server Type    : MySQL
 Target Server Version : 80200 (8.2.0)
 File Encoding         : 65001

 Date: 11/01/2024 11:39:17
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for store_coupon_goods_sku
-- ----------------------------
DROP TABLE IF EXISTS `store_coupon_goods_sku`;
CREATE TABLE `store_coupon_goods_sku` (
  `coupon_goods_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '优惠券商品ID',
  `tenant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '租户ID',
  `store_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺ID',
  `store_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '店铺名称',
  `coupon_template_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '优惠券模版ID',
  `coupon_template_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '优惠券模板名称',
  `goods_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品ID',
  `goods_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品名称',
  `sku_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'SKUID',
  `sku_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'SKU名称',
  `coupon_sku_stock` int NOT NULL COMMENT '本次SKU库存',
  `coupon_sku_sale_price` decimal(12,2) DEFAULT NULL COMMENT 'SKU销售价',
  `coupon_sku_profit` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT 'SKU利润',
  `is_enable` tinyint NOT NULL DEFAULT '1' COMMENT '是否可用',
  `remarks` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '修改时间',
  PRIMARY KEY (`coupon_goods_id`) USING BTREE,
  KEY `idx_store_coupon_goods_sku_store_id` (`store_id`) USING BTREE,
  KEY `idx_store_coupon_goods_sku_template_id` (`coupon_template_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='店铺优惠券商品关联表';

-- ----------------------------
-- Records of store_coupon_goods_sku
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for store_coupon_instance
-- ----------------------------
DROP TABLE IF EXISTS `store_coupon_instance`;
CREATE TABLE `store_coupon_instance` (
  `coupon_instance_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '券实例ID',
  `tenant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '租户ID',
  `store_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺ID',
  `store_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺名称',
  `coupon_template_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '优惠券模板ID',
  `coupon_template_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '优惠券模板名称',
  `coupon_template_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '优惠券模板类型',
  `member_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '成员ID',
  `member_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '成员名称',
  `phone_number` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '成员手机号码',
  `limit_amount` decimal(12,2) DEFAULT '0.00' COMMENT '满足金额',
  `discount_amount` decimal(12,2) DEFAULT '0.00' COMMENT '折扣金额',
  `receive_start_time` datetime(6) NOT NULL COMMENT '领用开始时间',
  `receive_end_time` datetime(6) NOT NULL COMMENT '领用结束时间',
  `usage_start_time` datetime(6) DEFAULT NULL COMMENT '使用开始时间',
  `usage_end_time` datetime(6) DEFAULT NULL COMMENT '使用结束时间',
  `received_time` datetime(6) DEFAULT NULL COMMENT '领取时间',
  `usage_time` datetime(6) DEFAULT NULL COMMENT '使用时间',
  `is_used` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已经使用',
  `instance_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'WAIT_USE' COMMENT '券实例状态  未使用-WAIT_USE 已使用- USED  已过期 -EXPIRED 冻结-FROZEN',
  `coupon_instructions` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '优惠券使用说明',
  `coupon_remarks` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '优惠券备注',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '修改时间',
  PRIMARY KEY (`coupon_instance_id`) USING BTREE,
  KEY `idx_store_coupon_instance_member_id` (`member_id`) USING BTREE,
  KEY `idx_store_coupon_instance_template_id` (`coupon_template_id`) USING BTREE,
  KEY `idx_store_coupon_instance_store_id` (`store_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='店铺优惠券实例表';

-- ----------------------------
-- Records of store_coupon_instance
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for store_coupon_template
-- ----------------------------
DROP TABLE IF EXISTS `store_coupon_template`;
CREATE TABLE `store_coupon_template` (
  `coupon_template_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '优惠券模板ID',
  `tenant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '租户ID',
  `store_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺ID',
  `store_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '店铺名称',
  `coupon_template_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '优惠券模板名称',
  `coupon_template_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '优惠券模板类型(满减，折扣券)',
  `limit_amount` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '满足金额',
  `discount_amount` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '抵扣金额',
  `discount_ratio` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '折扣比例',
  `coupon_cover_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '优惠券封面',
  `coupon_stock` int NOT NULL COMMENT '优惠券库存',
  `coupon_available_stock` int NOT NULL COMMENT '优惠券可用库存',
  `received_num` int NOT NULL DEFAULT '0' COMMENT '已领取人数',
  `limit_partake_quantity` int NOT NULL DEFAULT '0' COMMENT '限制参与次数',
  `is_enable` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否有效',
  `sort_value` int DEFAULT NULL COMMENT '排序',
  `receive_start_time` datetime(6) NOT NULL COMMENT '领用开始时间',
  `receive_end_time` datetime(6) NOT NULL COMMENT '领用结束时间',
  `usage_start_time` datetime(6) DEFAULT NULL COMMENT '使用开始时间',
  `usage_end_time` datetime(6) DEFAULT NULL COMMENT '使用结束时间',
  `coupon_template_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'DRAFT' COMMENT '优惠券模板状态',
  `usage_time_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'TIME_INTERVAL' COMMENT '使用时间类型(时间区间 ,领取后n小时失效)',
  `received_expire_hours` int NOT NULL DEFAULT '0' COMMENT '领取后过期小时数',
  `coupon_instructions` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '优惠券使用说明',
  `coupon_remarks` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '优惠券备注',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '修改时间',
  PRIMARY KEY (`coupon_template_id`) USING BTREE,
  KEY `idx_store_coupon_template_available_num` (`coupon_available_stock`) USING BTREE,
  KEY `idx_store_coupon_template_is_online_status` (`is_enable`) USING BTREE,
  KEY `idx_store_coupon_template_store_id` (`store_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='店铺优惠券模版';

-- ----------------------------
-- Records of store_coupon_template
-- ----------------------------
BEGIN;
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
