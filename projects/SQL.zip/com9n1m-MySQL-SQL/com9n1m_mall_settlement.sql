/*
 Navicat Premium Data Transfer

 Source Server         : 跳蚤项目（120.79.84.114 -docker-Mysql8.0）
 Source Server Type    : MySQL
 Source Server Version : 80200 (8.2.0)
 Source Host           : 120.79.84.114:9989
 Source Schema         : com9n1m_mall_settlement

 Target Server Type    : MySQL
 Target Server Version : 80200 (8.2.0)
 File Encoding         : 65001

 Date: 11/01/2024 11:39:24
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

SET FOREIGN_KEY_CHECKS = 1;
