/*
 Navicat Premium Data Transfer

 Source Server         : 跳蚤项目（120.79.84.114 -docker-Mysql8.0）
 Source Server Type    : MySQL
 Source Server Version : 80200 (8.2.0)
 Source Host           : 120.79.84.114:9989
 Source Schema         : com9n1m_mall_order

 Target Server Type    : MySQL
 Target Server Version : 80200 (8.2.0)
 File Encoding         : 65001

 Date: 11/01/2024 11:36:24
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for after_sale
-- ----------------------------
DROP TABLE IF EXISTS `after_sale`;
CREATE TABLE `after_sale` (
  `after_sale_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '售后单ID',
  `member_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '会员ID',
  `merchant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商户ID',
  `tenant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '租户ID',
  `store_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺ID',
  `store_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺名称',
  `order_id` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单ID',
  `order_detail_id` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单明细ID',
  `after_service_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '售后类型(ONLY_REFUND仅退款,REFUND_RETURN_GOODS退款退货)',
  `after_service_reason_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '售后原因类型',
  `after_service_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '售后原因',
  `after_service_request_time` datetime(6) NOT NULL COMMENT '售后服务申请时间',
  `after_service_img_url` varchar(600) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '售后图片url,逗号分割',
  `refund_amount` decimal(16,4) DEFAULT '0.0000' COMMENT '退款金额',
  `goods_id` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品ID',
  `goods_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品名称',
  `goods_code` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品编码',
  `sku_id` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '申请SKU ID',
  `sku_code` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'SKU编码',
  `sku_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'SKU名称',
  `sku_quantity` int DEFAULT NULL COMMENT '申请SKU数量',
  `sku_img_url` varchar(600) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'SKU图片',
  `address_detail` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '收货地址详情',
  `address_consignee` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '收件人',
  `address_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '收件人联系电话',
  `audit_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '审核状态(NONE-未审核,M_PASS-通过,M_REJECT-拒绝)',
  `after_service_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '售后服务状态(COMMITTED-已提交 WAIT_AUDIT-等待审核 AUDIT_REJECT-已拒绝 AUDIT_PASS-已通过 WAIT_SEND-等待买家发货 SENT-买家已发货 WAIT_RECEIVE-等待卖家收货 RECEIVE_PASS-卖家验货通过 RECEIVE_REJECT-卖家验货失败 WAIT_REFUND-等待退款 REFUNDED-已退款 FINISHED-已完成 CLOSED-已关闭)',
  `arb_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '仲裁状态(NONE-无冲裁,C_ARB-用户发起冲裁,ARB_PASS-仲裁通过,ARB_REJECT-仲裁拒绝)',
  `return_logistic_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '回寄物流公司名称',
  `return_logistic_waybill_no` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '回寄物流单号',
  `refund_id` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '退款单ID',
  `refund_time` datetime(6) DEFAULT NULL COMMENT '退款时间',
  `refund_freight_amount` decimal(16,4) DEFAULT '0.0000' COMMENT '运费退款金额',
  `refund_goods_amount` decimal(16,4) DEFAULT '0.0000' COMMENT '商品退款金额',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`after_sale_id`) USING BTREE,
  KEY `idx_after_sale_member_id` (`member_id`) USING BTREE,
  KEY `idx_after_sale_ store_id` (`store_id`) USING BTREE,
  KEY `idx_after_sale_order` (`order_id`,`order_detail_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='售后单';

-- ----------------------------
-- Records of after_sale
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for after_sale_log
-- ----------------------------
DROP TABLE IF EXISTS `after_sale_log`;
CREATE TABLE `after_sale_log` (
  `after_sale_log_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '售后单日志id',
  `after_sale_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '售后单id',
  `pre_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '上一步售后状态',
  `current_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '当前售后状态',
  `remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  `user_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '步骤操作者id',
  `img_url` varchar(600) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '图片url,逗号分隔',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`after_sale_log_id`) USING BTREE,
  KEY `idx_after_sale_log_after_sale_id` (`after_sale_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='售后单日志';

-- ----------------------------
-- Records of after_sale_log
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for cart_info
-- ----------------------------
DROP TABLE IF EXISTS `cart_info`;
CREATE TABLE `cart_info` (
  `cart_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '购物车ID',
  `member_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '成员ID',
  `cart_info_json` json NOT NULL COMMENT '购物车信息',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '修改时间',
  PRIMARY KEY (`cart_id`),
  UNIQUE KEY `idx_cart_info_member_id` (`member_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='购物车记录表';

-- ----------------------------
-- Records of cart_info
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for order_complaint
-- ----------------------------
DROP TABLE IF EXISTS `order_complaint`;
CREATE TABLE `order_complaint` (
  `order_complaint_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '异常订单投诉单ID',
  `tenant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '租户ID',
  `store_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '店铺ID',
  `store_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '店铺名称',
  `member_id` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '消费者ID',
  `member_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '消费者昵称',
  `member_phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '消费者电话',
  `order_id` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '订单ID',
  `order_detail_id` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '订单详情ID',
  `goods_id` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品ID',
  `sku_id` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'SKU ID',
  `goods_name` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品名称',
  `sku_name` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'sku名称',
  `sku_img_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'sku图片链接',
  `sku_cost_price` decimal(16,4) DEFAULT NULL COMMENT 'sku供货价',
  `sku_sale_price` decimal(16,4) DEFAULT NULL COMMENT 'sku销售价',
  `sku_quantity` int DEFAULT NULL COMMENT '商品数量',
  `sku_amount` decimal(16,4) DEFAULT NULL COMMENT '实付金额',
  `order_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '订单状态(UNCOMMIT-0-未提交,COMMITTED-1-已提交,PAYED-2-已支付,SENT-4-已发货,RECEIVED-8-已签收,FINISHED-16-已完成,CLOSED-32-已关闭)',
  `order_create_time` datetime(6) DEFAULT NULL COMMENT '下单时间',
  `order_send_time` datetime(6) DEFAULT NULL COMMENT '发货时间',
  `order_receive_time` datetime(6) DEFAULT NULL COMMENT '收货时间',
  `order_finish_time` datetime(6) DEFAULT NULL COMMENT '完成时间',
  `complaint_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '投诉说明',
  `complaint_pictures` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '举证图片(多张用英文逗号隔开)',
  `complaint_videos` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '举证视频链接',
  `complaint_state` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '投诉状态(AUDITING-平台审核中,PROCESSING-商家处理中,REJECT-平台拒绝,FINISHED-已处理,CLOSED-已关闭,CANCEL-已取消)',
  `admin_id` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '平台审核人ID',
  `admin_handle_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '平台审核结果说明',
  `admin_handle_state` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '平台审核结果(PASS-通过, REFUSE-驳回)',
  `admin_handle_pictures` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '平台审核图片(多张用英文逗号隔开)',
  `admin_handle_remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '平台审核备注',
  `admin_handle_time` datetime(6) DEFAULT NULL COMMENT '平台审核时间',
  `merchant_handle_reason` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商家处理结果说明',
  `merchant_handle_state` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商家处理结果(PASS-通过, REFUSE-驳回)',
  `merchant_handle_pictures` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT '商家处理图片(多张用英文逗号隔开)',
  `merchant_handle_remark` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商家处理备注',
  `merchant_handle_time` datetime(6) DEFAULT NULL COMMENT '商家处理时间',
  `create_time` datetime(6) NOT NULL COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`order_complaint_id`) USING BTREE,
  KEY `idx_order_complaint_store_id` (`store_id`) USING BTREE,
  KEY `idx_order_complaint_member_id` (`member_id`) USING BTREE,
  KEY `idx_order_complaint_order` (`order_id`,`order_detail_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='异常订单投诉单';

-- ----------------------------
-- Records of order_complaint
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for order_detail
-- ----------------------------
DROP TABLE IF EXISTS `order_detail`;
CREATE TABLE `order_detail` (
  `order_detail_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单详情ID',
  `order_main_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '主订单ID',
  `order_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单ID',
  `sku_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'SKUID',
  `sku_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'SKU名称',
  `goods_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品ID',
  `goods_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品名称',
  `category_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '分类ID',
  `category_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '分类名称',
  `category_id_path` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '类目ID路径,用-分隔',
  `category_name_path` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '类目名称路径,用-分隔',
  `sku_label_price` decimal(12,2) DEFAULT '0.00' COMMENT '标签价',
  `sku_sale_price` decimal(12,2) DEFAULT '0.00' COMMENT '销售价',
  `sku_cost_price` decimal(12,2) DEFAULT '0.00' COMMENT '成本价',
  `sku_quantity` int NOT NULL COMMENT '交易数量',
  `sku_amount` decimal(12,2) DEFAULT NULL COMMENT '商品金额',
  `tenant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '租户ID',
  `store_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '店铺ID',
  `member_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '会员ID',
  `sku_attr_json` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'sku的规格json字符串',
  `discount_amount` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '优惠金额',
  `coupon_discount_amount` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '优惠券优惠金额',
  `coupon_ids` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '涉及的优惠券,逗号分割',
  `goods_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品编码',
  `sku_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'sku编码',
  `sku_weight` decimal(12,2) DEFAULT '0.00' COMMENT '规格重量',
  `sku_img_url` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'sku商品的logo链接',
  `sku_refund_expires_time` datetime DEFAULT NULL COMMENT 'sku售后终止时间',
  `send_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'UNSEND' COMMENT '发货状态(UNSEND-未发货,PART-部分发货,ALL-全部发货)',
  `send_time` datetime(3) DEFAULT NULL COMMENT '发货日期',
  `refund_quantity` int NOT NULL DEFAULT '0' COMMENT '售后退货数量',
  `refund_amount` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '售后退款金额',
  `refund_goods_amount` decimal(12,2) DEFAULT '0.00' COMMENT '售后商品金额',
  `refund_freight_amount` decimal(12,2) DEFAULT '0.00' COMMENT '售后运费金额',
  `order_freight_calculate_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '运费计算表主键ID',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`order_detail_id`) USING BTREE,
  KEY `idx_order_detail_goods_name` (`goods_name`) USING BTREE,
  KEY `idx_order_detail_order_id` (`order_id`) USING BTREE,
  KEY `idx_order_detail_order_main_id` (`order_main_id`) USING BTREE,
  KEY `idx_order_detail_goods_code` (`goods_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='订单详情表（SKU级）';

-- ----------------------------
-- Records of order_detail
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for order_freight_calculate
-- ----------------------------
DROP TABLE IF EXISTS `order_freight_calculate`;
CREATE TABLE `order_freight_calculate` (
  `order_freight_calculate_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '' COMMENT '订单商品运费计算表主键ID',
  `order_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单ID',
  `freight_template_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '运费模板ID',
  `freight_template_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品运费模板名称',
  `freight_way` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '运费计算方式(FREE-包邮, FIXED-固定运费, TEMP-模板运费)',
  `first_num` int DEFAULT NULL COMMENT '首单位数',
  `first_freight` decimal(12,2) DEFAULT NULL COMMENT '首单位价',
  `continue_num` int DEFAULT NULL COMMENT '续单位数',
  `continue_freight` decimal(12,2) DEFAULT NULL COMMENT '续单位价',
  `template_freight_amount` decimal(12,2) NOT NULL COMMENT '当前模板商品运费总金额',
  `refund_quantity` int NOT NULL DEFAULT '0' COMMENT '售后数量',
  `refund_freight_amount` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '售后已退运费金额',
  `update_time` datetime(6) NOT NULL COMMENT '更新时间',
  `create_time` datetime(6) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`order_freight_calculate_id`) USING BTREE,
  KEY `idx_order_freight_calculate_order_id` (`order_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='订单商品运费计算表';

-- ----------------------------
-- Records of order_freight_calculate
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for order_goods_snap
-- ----------------------------
DROP TABLE IF EXISTS `order_goods_snap`;
CREATE TABLE `order_goods_snap` (
  `order_detail_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单详情ID',
  `order_main_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '主订单ID',
  `order_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单ID',
  `spu_json` json DEFAULT NULL COMMENT 'SPU相关',
  `sku_json` json DEFAULT NULL COMMENT 'SKU相关',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`order_detail_id`),
  KEY `idx_order_goods_snap_order_main_id` (`order_main_id`) USING BTREE,
  KEY `idx_order_goods_snap_order_id` (`order_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='订单商品快照表';

-- ----------------------------
-- Records of order_goods_snap
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for order_info
-- ----------------------------
DROP TABLE IF EXISTS `order_info`;
CREATE TABLE `order_info` (
  `order_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单ID',
  `order_main_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '主订单ID',
  `tenant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '租户ID',
  `store_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺ID',
  `store_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '店铺名称',
  `order_create_time` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) COMMENT '主订单创建时间',
  `member_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '成员ID',
  `member_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '成员名称',
  `order_goods_quantity` int NOT NULL COMMENT '订单商品总数量',
  `order_goods_amount` decimal(12,2) NOT NULL COMMENT '订单商品总额',
  `order_goods_discount_amount` decimal(12,2) DEFAULT NULL COMMENT '订单商品折扣总金额',
  `order_cost_amount` decimal(12,2) NOT NULL COMMENT '订单供货价',
  `order_freight_amount` decimal(12,2) DEFAULT NULL COMMENT '运费',
  `order_amount` decimal(12,2) DEFAULT NULL COMMENT '订单总额(order_goods_amount+order_freight_amount)',
  `order_payment_amount` decimal(12,2) DEFAULT NULL COMMENT '实付金额(order_goods_amount-order_goods_discount_amount+order_freight_amount)',
  `address_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户收货地址ID',
  `address_province` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '收货地址省份',
  `address_city` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '收货地址城市',
  `address_area` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '收货地址行政区',
  `address_street` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '收货地址街道',
  `address_detail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '收货地址详情',
  `address_consignee` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '收件人',
  `address_phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '收件人联系电话',
  `order_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '订单状态(UNCOMMIT-0-未提交,COMMITTED-1-已提交,PAYED-2-已支付,SENT-4-已发货,RECEIVED-8-已签收,FINISHED-16-已完成,CLOSED-32-已关闭)',
  `send_status` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'UNSEND' COMMENT '发货状态(UNSEND-未发货,PART-部分发货,ALL-全部发货)',
  `order_close_reason` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '交易关闭原因(CLIENT-用户取消,TIMEOUT-支付超时,MERCHANT-商户取消,SYSTEM-平台取消)',
  `pay_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '支付方式(PAYFIRST-先款,PAYLAST-货到付款)',
  `is_commented` tinyint(1) DEFAULT '0' COMMENT '是否评价过',
  `is_payed` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否完成支付',
  `is_sended` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否发货',
  `is_received` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否收货',
  `is_closed` tinyint(1) NOT NULL DEFAULT '0' COMMENT '交易是否关闭',
  `is_finished` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否已完成',
  `is_invoice` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否开票',
  `order_memo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '订单备注',
  `in_after_service_count` int DEFAULT '0' COMMENT '正在进项的售后条数',
  `finish_time` datetime(3) DEFAULT NULL COMMENT '完成日期',
  `cancel_time` datetime(3) DEFAULT NULL COMMENT '取消日期',
  `send_time` datetime(3) DEFAULT NULL COMMENT '发货日期',
  `confirm_receive_time` datetime(3) DEFAULT NULL COMMENT '确认收货时间',
  `receive_time` datetime(3) DEFAULT NULL COMMENT '收货日期',
  `invoice_time` datetime(3) DEFAULT NULL COMMENT '开票时间',
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  `is_separate_account` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否分账',
  `separate_account_time` datetime(3) DEFAULT NULL COMMENT '分账时间',
  `pay_time` datetime(3) DEFAULT NULL COMMENT '支付时间',
  `pay_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '支付状态(UNPAY,PAYED,CANCELED)',
  `sub_mchid` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '二级商户id,支付用',
  `invoice_status` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'UNREQUEST' COMMENT '开票状态(UNREUQEST-未申请,REUQEST-已申请,INVOICED-已开具)',
  `pay_transaction_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '支付交易id(支付平台的支付id)',
  `merchant_company_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '结算主题名称',
  `refund_quantity` int NOT NULL DEFAULT '0' COMMENT '售后退货数量',
  `refund_amount` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '售后退款金额',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`order_id`) USING BTREE,
  KEY `idx_order_info_order_main_id` (`order_main_id`) USING BTREE,
  KEY `idx_order_info_member_id` (`member_id`) USING BTREE,
  KEY `idx_order_info_is_payed` (`is_payed`) USING BTREE,
  KEY `idx_order_info_is_sended` (`is_sended`) USING BTREE,
  KEY `idx_order_info_is_received` (`is_received`) USING BTREE,
  KEY `idx_order_info_is_finished` (`is_finished`) USING BTREE,
  KEY `idx_order_info_is_closed` (`is_closed`) USING BTREE,
  KEY `idx_order_info_order_status` (`order_status`) USING BTREE,
  KEY `idx_order_info_store_id` (`store_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='订单表（店铺级）';

-- ----------------------------
-- Records of order_info
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for order_main_info
-- ----------------------------
DROP TABLE IF EXISTS `order_main_info`;
CREATE TABLE `order_main_info` (
  `order_main_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '主订单ID',
  `member_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '用户ID',
  `order_main_goods_quantity` int NOT NULL COMMENT '订单商品总数量',
  `order_main_goods_amount` decimal(12,2) NOT NULL COMMENT '订单商品总额',
  `order_main_goods_discount_amount` decimal(12,2) DEFAULT NULL COMMENT '订单商品折扣总金额',
  `order_main_freight_amount` decimal(12,2) DEFAULT NULL COMMENT '运费',
  `order_main_amount` decimal(12,2) DEFAULT NULL COMMENT '订单总额(order_main_goods_amount+order_main_freight_amount)',
  `order_main_payment_amount` decimal(12,2) DEFAULT NULL COMMENT '实付金额(order_main_goods_amount-order_main_goods_discount_amount+order_main_freight_amount)',
  `order_main_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '主订单状态(UNCOMMIT,COMMITED,CANCELED,PAYED)',
  `pay_time` datetime DEFAULT NULL COMMENT '支付时间',
  `pay_status` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'UNPAY' COMMENT '支付状态(UNPAY,PAYED,CANCELED)',
  `prepay_id` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '预支付ID',
  `pay_begin_time` datetime DEFAULT NULL COMMENT '开始支付会话时间',
  `pay_expire_time` datetime DEFAULT NULL COMMENT '支付会话过期时间',
  `pay_finish_time` datetime DEFAULT NULL COMMENT '支付完成时间',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`order_main_id`) USING BTREE,
  KEY `idx_order_main_info_memberid_paystatus` (`member_id`,`pay_status`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC COMMENT='订单主表（聚合店铺）';

-- ----------------------------
-- Records of order_main_info
-- ----------------------------
BEGIN;
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
