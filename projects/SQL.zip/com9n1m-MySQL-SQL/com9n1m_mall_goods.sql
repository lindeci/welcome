/*
 Navicat Premium Data Transfer

 Source Server         : 跳蚤项目（120.79.84.114 -docker-Mysql8.0）
 Source Server Type    : MySQL
 Source Server Version : 80200 (8.2.0)
 Source Host           : 120.79.84.114:9989
 Source Schema         : com9n1m_mall_goods

 Target Server Type    : MySQL
 Target Server Version : 80200 (8.2.0)
 File Encoding         : 65001

 Date: 11/01/2024 11:35:38
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for goods_apply
-- ----------------------------
DROP TABLE IF EXISTS `goods_apply`;
CREATE TABLE `goods_apply` (
  `apply_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '申请ID',
  `apply_title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '申请标题',
  `apply_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品创建审核，CREATE_APPLY,PRICE_APPLY',
  `goods_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品ID',
  `goods_data` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品对象JSON',
  `audit_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '审核状态,READY,PRE_AUDIT,POST_AUDIT,APPROVE,REJECT',
  `apply_time` datetime(6) DEFAULT NULL COMMENT '申请时间',
  `pre_audit_admin_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '初审管理员ID',
  `pre_audit_admin_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '初审管理员名字',
  `pre_audit_time` datetime(6) DEFAULT NULL COMMENT '初审核时间',
  `pre_audit_remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '初审备注',
  `post_audit_admin_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '终审管理员ID',
  `post_audit_admin_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '终审管理员名字',
  `post_audit_time` datetime(6) DEFAULT NULL COMMENT '终审时间',
  `post_audit_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '终审原因',
  `tenant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '租户ID',
  `store_id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺ID',
  `store_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺名字',
  `attach_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '附件地址',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`apply_id`),
  KEY `idx_goods_apply_apply_type` (`apply_type`) USING BTREE,
  KEY `idx_goods_apply_goods_id` (`goods_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商品审批流程表';

-- ----------------------------
-- Records of goods_apply
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_apply_log
-- ----------------------------
DROP TABLE IF EXISTS `goods_apply_log`;
CREATE TABLE `goods_apply_log` (
  `apply_log_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '申请记录ID',
  `apply_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '申请ID',
  `apply_title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '申请标题',
  `apply_log_desc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '本次审核说明',
  `before_apply_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '审核前状态',
  `after_apply_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '审核后状态',
  `audit_admin_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '审核管理员ID',
  `audit_admin_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '审核管理员名字',
  `apply_remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '审核备注',
  `create_time` datetime(6) NOT NULL COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`apply_log_id`),
  KEY `idx_goods_apply_log_apply_id` (`apply_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商品审批日志表';

-- ----------------------------
-- Records of goods_apply_log
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_brand
-- ----------------------------
DROP TABLE IF EXISTS `goods_brand`;
CREATE TABLE `goods_brand` (
  `brand_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '品牌ID',
  `brand_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '品牌名字',
  `brand_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '品牌编码',
  `brand_acronym` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '首字母缩写',
  `sort_value` int DEFAULT NULL COMMENT '排序',
  `brand_logo_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '品牌LOGO',
  `brand_cover_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '品牌封面大图',
  `brand_factory` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '品牌制造商',
  `brand_story` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '品牌故事',
  `edit_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'DRAFT' COMMENT '编辑状态，分为DRAFT,IN_EDIT,RELEASE',
  `audit_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'READY' COMMENT '审核状态,READY,PRE_AUDIT,POST_AUDIT,APPROVE,REJECT',
  `pre_audit_time` datetime(6) DEFAULT NULL COMMENT '初审时间',
  `pre_audit_remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '初审,审核备注',
  `post_audit_time` datetime(6) DEFAULT NULL COMMENT '终审时间',
  `post_audit_remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '终审,审核备注',
  `first_shelves_time` datetime(6) DEFAULT NULL COMMENT '商品初次上架时间',
  `down_shelf_time` datetime(6) DEFAULT NULL COMMENT '商品下架时间',
  `is_online` tinyint(1) DEFAULT '0' COMMENT '是否在线',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`brand_id`),
  UNIQUE KEY `idx_goods_brand_brand_name` (`brand_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商品品牌表';

-- ----------------------------
-- Records of goods_brand
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_brand_apply
-- ----------------------------
DROP TABLE IF EXISTS `goods_brand_apply`;
CREATE TABLE `goods_brand_apply` (
  `brand_apply_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '申请ID',
  `brand_apply_title` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '申请标题',
  `brand_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '品牌ID',
  `brand_data` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '品牌对象JSON',
  `audit_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'READY' COMMENT '审核状态,(READY,PRE_AUDIT,POST_AUDIT,APPROVE,REJECT)',
  `apply_time` datetime(6) DEFAULT NULL COMMENT '申请时间',
  `pre_audit_admin_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '初审管理员ID',
  `pre_audit_admin_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '初审管理员名字',
  `pre_audit_time` datetime(6) DEFAULT NULL COMMENT '初审核时间',
  `pre_audit_remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '初审备注',
  `post_audit_admin_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '终审管理员ID',
  `post_audit_admin_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '终审管理员名字',
  `post_audit_time` datetime(6) DEFAULT NULL COMMENT '终审时间',
  `post_audit_remarks` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '终审备注',
  `tenant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '租户ID',
  `store_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '店铺ID',
  `store_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺名称',
  `attach_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '附件地址',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`brand_apply_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='品牌流程受理单表';

-- ----------------------------
-- Records of goods_brand_apply
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_brand_apply_log
-- ----------------------------
DROP TABLE IF EXISTS `goods_brand_apply_log`;
CREATE TABLE `goods_brand_apply_log` (
  `brand_apply_log_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '品牌申请记录ID',
  `brand_apply_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '申请ID',
  `brand_apply_title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '申请标题',
  `brand_apply_log_desc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '本次审核说明',
  `before_apply_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '审核前状态',
  `after_apply_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '审核后状态',
  `apply_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '审核原因',
  `audit_admin_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '审核管理员ID',
  `audit_admin_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '审核管理员名字',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`brand_apply_log_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='品牌受理单日志表';

-- ----------------------------
-- Records of goods_brand_apply_log
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_category
-- ----------------------------
DROP TABLE IF EXISTS `goods_category`;
CREATE TABLE `goods_category` (
  `category_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '分类ID',
  `category_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '分类编码',
  `category_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '分类名字',
  `is_leaf` tinyint(1) NOT NULL COMMENT '是否叶子节点',
  `level_num` int NOT NULL COMMENT '层级级别',
  `parent_category_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '上级分类ID',
  `category_img_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '分类图标',
  `sort_value` int NOT NULL COMMENT '排序',
  `is_online` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否在线',
  `service_fee_scale` decimal(12,2) DEFAULT '0.00' COMMENT '服务费比例',
  `tax_fee_scale` decimal(12,2) DEFAULT '0.00' COMMENT '税率比例',
  `tax_fee_name` varchar(50) COLLATE utf8mb4_general_ci DEFAULT '0.00' COMMENT '税率类目名称',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`category_id`) USING BTREE,
  KEY `idx_goods_category_name` (`category_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商品基本类目表';

-- ----------------------------
-- Records of goods_category
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_category_deposit
-- ----------------------------
DROP TABLE IF EXISTS `goods_category_deposit`;
CREATE TABLE `goods_category_deposit` (
  `category_deposit_id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '分类保证金ID',
  `category_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '分类ID',
  `deposit_amount` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '保证金金额',
  `alert_amount` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '告警金额',
  `closure_amount` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '封店金额',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`category_deposit_id`) USING BTREE,
  KEY `idx_goods_category_deposit_category_id` (`category_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商品类目保证金表';

-- ----------------------------
-- Records of goods_category_deposit
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_freight_info
-- ----------------------------
DROP TABLE IF EXISTS `goods_freight_info`;
CREATE TABLE `goods_freight_info` (
  `goods_freight_id` varbinary(50) NOT NULL COMMENT '商品运费ID',
  `goods_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品ID',
  `freight_template_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '运费模板ID',
  `freight_template_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '模板名称',
  `fixed_amount` decimal(12,2) DEFAULT NULL COMMENT '固定运费金额',
  `freight_way` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '运费计算方式(FREE-包邮, FIXED-固定运费, TEMP-模板运费)',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`goods_freight_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商品运费关联表';

-- ----------------------------
-- Records of goods_freight_info
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_freight_region
-- ----------------------------
DROP TABLE IF EXISTS `goods_freight_region`;
CREATE TABLE `goods_freight_region` (
  `freight_region_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '可配送区域ID',
  `freight_template_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '运费模板ID',
  `region_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '区域名称',
  `region_code` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '区域编码',
  `region_level` int NOT NULL COMMENT '区域等级(1-省，2-市)',
  `is_region_free` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否区域包邮',
  `is_enable_free_amount` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否支持消费包邮',
  `free_amount` decimal(12,2) DEFAULT NULL COMMENT '消费包邮金额',
  `create_time` datetime(6) NOT NULL COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`freight_region_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='运费模板配送区域表';

-- ----------------------------
-- Records of goods_freight_region
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_freight_rule
-- ----------------------------
DROP TABLE IF EXISTS `goods_freight_rule`;
CREATE TABLE `goods_freight_rule` (
  `freight_rule_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '规则主键ID',
  `freight_template_id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL COMMENT '运费模板ID',
  `freight_region_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '可配送区域ID',
  `first_num` int DEFAULT NULL COMMENT '首单位数',
  `first_freight` decimal(12,2) DEFAULT NULL COMMENT '首单位价',
  `continue_num` int DEFAULT NULL COMMENT '续单位数',
  `continue_freight` decimal(12,2) DEFAULT NULL COMMENT '续单位价',
  `freight_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '计费方式：PIECE-计件，WEIGHT-计重，VOLUME-体积',
  `create_time` datetime(6) NOT NULL COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`freight_rule_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='运费模板区域规则';

-- ----------------------------
-- Records of goods_freight_rule
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_freight_template
-- ----------------------------
DROP TABLE IF EXISTS `goods_freight_template`;
CREATE TABLE `goods_freight_template` (
  `freight_template_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '运费模板ID',
  `freight_template_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '运费模板名称',
  `tenant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '租户ID',
  `store_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺ID',
  `create_time` datetime(6) NOT NULL COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`freight_template_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='运费模板';

-- ----------------------------
-- Records of goods_freight_template
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_sku
-- ----------------------------
DROP TABLE IF EXISTS `goods_sku`;
CREATE TABLE `goods_sku` (
  `sku_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'SKU ID',
  `tenant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '租户ID',
  `store_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺ID',
  `goods_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品ID',
  `sku_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'SKU 名字',
  `sku_img_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'SKU商品的Logo链接',
  `sku_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'SKU Code',
  `external_sku_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '外部主数据ID',
  `external_sku_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '外部主数据SKU名字',
  `sku_checksum` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'SKU的ATTR_VALUE_ID排序字符串连接后按MD5，在同一个商品下唯一，避免重复sku',
  `sku_min_buy_num` int NOT NULL DEFAULT '0' COMMENT '商品最低起售量',
  `sku_label_price` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '标签价',
  `sku_sale_price` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '销售价',
  `sku_cost_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '成本价或供应商价',
  `sku_settlement_price` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '店铺结算价',
  `sku_weight` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '规格重量',
  `sku_volume` decimal(20,2) NOT NULL DEFAULT '0.00' COMMENT '规格体积',
  `goods_kinds_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品类型(普通商品-ORDINARY_GOODS  赠品-PRESENT_GOODS  )',
  `is_virtual` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否虚拟商品',
  `sku_stock` int NOT NULL DEFAULT '0' COMMENT '规格库存',
  `sku_sale_num` int NOT NULL DEFAULT '0' COMMENT '规格销量',
  `is_online` tinyint(1) NOT NULL COMMENT '是否上架',
  `service_fee_scale` decimal(12,2) DEFAULT '0.00' COMMENT '服务费比例',
  `tax_fee_scale` decimal(12,2) DEFAULT '0.00' COMMENT '税率比例',
  `version` int NOT NULL DEFAULT '0' COMMENT '并发版本',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  `goods_specifications_json` text COLLATE utf8mb4_general_ci COMMENT '属性参数JSON',
  PRIMARY KEY (`sku_id`) USING BTREE,
  UNIQUE KEY `idx_goods_sku_sku_checksum` (`sku_checksum`) USING BTREE,
  KEY `idx_goods_sku_store_id` (`store_id`) USING BTREE,
  KEY `idx_goods_sku_goods_id` (`goods_id`) USING BTREE,
  KEY `idx_goods_sku_sku_name` (`sku_name`) USING BTREE,
  KEY `idx_goods_sku_sku_code` (`sku_code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='SKU实体表';

-- ----------------------------
-- Records of goods_sku
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_sku_attr_group
-- ----------------------------
DROP TABLE IF EXISTS `goods_sku_attr_group`;
CREATE TABLE `goods_sku_attr_group` (
  `attr_group_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '属性分组值ID',
  `goods_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品ID',
  `sku_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'SKU ID',
  `attr_key_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '规格名ID',
  `attr_key_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '规格名名字',
  `attr_value_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '规格属性ID',
  `attr_value_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '规格属性名字',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`attr_group_id`),
  KEY `idx_goods_sku_attr_group_goods_id` (`goods_id`) USING BTREE,
  KEY `idx_goods_sku_attr_group_sku_id` (`sku_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商品规模属性组表';

-- ----------------------------
-- Records of goods_sku_attr_group
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_sku_attr_key
-- ----------------------------
DROP TABLE IF EXISTS `goods_sku_attr_key`;
CREATE TABLE `goods_sku_attr_key` (
  `attr_key_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '规格ID',
  `attr_key_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '规格名字',
  `goods_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品ID',
  `version` int NOT NULL DEFAULT '0' COMMENT '并发版本',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`attr_key_id`),
  KEY `idx_goods_sku_attr_key_goods_id` (`goods_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='sku规格名称表';

-- ----------------------------
-- Records of goods_sku_attr_key
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_sku_attr_value
-- ----------------------------
DROP TABLE IF EXISTS `goods_sku_attr_value`;
CREATE TABLE `goods_sku_attr_value` (
  `attr_value_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '属性值ID',
  `attr_value_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '值的内容',
  `attr_key_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '规格ID',
  `attr_key_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '规格名字',
  `goods_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '归属商品id',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`attr_value_id`),
  KEY `idx_goods_sku_attr_value_goods_id` (`goods_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='sku规格属性表';

-- ----------------------------
-- Records of goods_sku_attr_value
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_specifications_key
-- ----------------------------
DROP TABLE IF EXISTS `goods_specifications_key`;
CREATE TABLE `goods_specifications_key` (
  `goods_specifications_key_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '属性ID',
  `goods_specifications_key_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '属性名称',
  `leaf_categroy_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '叶子类目ID',
  `leaf_categroy_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '叶子类目名称',
  `key_date_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '数据类型[STRING,LIST,DATE,NUMBER,DECIMAL]',
  `version` int NOT NULL DEFAULT '0' COMMENT '版本控制',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`goods_specifications_key_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商品属性名称表';

-- ----------------------------
-- Records of goods_specifications_key
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_specifications_key_template
-- ----------------------------
DROP TABLE IF EXISTS `goods_specifications_key_template`;
CREATE TABLE `goods_specifications_key_template` (
  `specifications_key_template_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '模板ID',
  `specifications_key_template_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '模板名称',
  `specifications_key_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '属性参数ID',
  `specifications_key_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '属性参数名称',
  `leaf_categroy_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '叶子类目ID',
  `leaf_categroy_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '叶子类目名称',
  `key_date_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '数据类型[STRING,LIST,DATE,NUMBER,DECIMAL]',
  `version` int NOT NULL DEFAULT '0' COMMENT '版本控制',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`specifications_key_template_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商品属性名称表';

-- ----------------------------
-- Records of goods_specifications_key_template
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_spu
-- ----------------------------
DROP TABLE IF EXISTS `goods_spu`;
CREATE TABLE `goods_spu` (
  `goods_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品ID',
  `goods_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品名称',
  `goods_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品编码',
  `merchant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商户ID',
  `tenant_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '租户ID',
  `store_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺ID',
  `store_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '店铺名称',
  `external_goods_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '外部商品ID',
  `external_goods_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '外部商品编码',
  `brand_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '品牌ID',
  `brand_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '品牌名称',
  `category_id1` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT '1级分类ID',
  `category_name1` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '1级分类名称',
  `category_id2` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT '2级分类ID',
  `category_name2` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '2级分类名称',
  `category_id3` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT '3级分类ID',
  `category_name3` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '3级分类名称',
  `leaf_category_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '叶子分类',
  `leaf_category_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '叶子节点名称',
  `leaf_category_level` int NOT NULL DEFAULT '3' COMMENT '叶子节点级别',
  `goods_introduction` varchar(2000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品简介',
  `goods_keyword` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品搜索关键字',
  `goods_jingle` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品广告词',
  `goods_cover_url_list` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品图片列表，多图片逗号隔开',
  `goods_compress_url_list` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品图片列表，多图片逗号隔开(小图)',
  `goods_video_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品小视频地址',
  `real_sale_num` int NOT NULL DEFAULT '0' COMMENT '真实月销量',
  `display_sale_num` int NOT NULL COMMENT '显示的月销量',
  `is_single_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否单品',
  `storage_num` int NOT NULL DEFAULT '0' COMMENT '显示库存，多个SKU总库存',
  `label_highest_price` decimal(12,2) NOT NULL COMMENT '最高标签价格或者划线价',
  `label_lower_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '最低标签价格或者划线价',
  `sale_highest_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '销售最高价',
  `sale_lower_price` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT '销售最低价',
  `qrcode_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '二维码地址',
  `goods_sort_order` bigint DEFAULT NULL COMMENT '商品排序字段',
  `goods_remark` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '商品手工备注',
  `edit_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'DRAFT' COMMENT '编辑状态，分为DRAFT,IN_EDIT,RELEASE',
  `audit_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'READY' COMMENT '审核状态,READY,PRE_AUDIT,POST_AUDIT,APPROVE,REJECT',
  `pre_audit_remarks` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '初审,审核备注',
  `pre_audit_time` datetime(6) DEFAULT NULL COMMENT '初审时间',
  `post_audit_remarks` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '终审,审核备注',
  `post_audit_time` datetime(6) DEFAULT NULL COMMENT '终审时间',
  `online_status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '在线状态，包括枚举类型(ONLINE,SELF_OFFLINE,PLATFORM_OFFLINE)',
  `is_online` tinyint(1) NOT NULL COMMENT '是否在线',
  `offline_reason` text COLLATE utf8mb4_general_ci COMMENT '下架原因',
  `is_enable_return_goods` tinyint(1) DEFAULT '0' COMMENT '是否支持退货',
  `is_enable_free_shipping` tinyint(1) DEFAULT '0' COMMENT '是否支持包邮',
  `is_owner` tinyint(1) DEFAULT '0' COMMENT '是否为平台自营商品',
  `return_days` int DEFAULT '0' COMMENT '退货支持天数',
  `comment_total_quantity` int DEFAULT NULL COMMENT '评价总数量',
  `comment_fine_quantity` int DEFAULT '0' COMMENT '好评数量',
  `comment_medium_quantity` int DEFAULT '0' COMMENT '中评数量',
  `comment_low_quantity` int DEFAULT '0' COMMENT '差评数量',
  `comment_fine_ratio` decimal(12,2) DEFAULT NULL COMMENT '好评率',
  `comment_medium_ratio` decimal(12,2) DEFAULT NULL COMMENT '中评率',
  `comment_low_ratio` decimal(12,2) DEFAULT NULL COMMENT '差评率',
  `first_shelves_time` datetime(6) DEFAULT NULL COMMENT '商品初次上架时间',
  `collect_num` int DEFAULT '0' COMMENT '收藏数量',
  `down_shelf_time` datetime(6) DEFAULT NULL COMMENT '商品下架时间',
  `goods_kinds_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'PRESENT_GOODS' COMMENT '商品类型(普通商品-ORDINARY_GOODS  赠品-PRESENT_GOODS  )',
  `is_able_dropshipping` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否支持一键代发',
  `is_virtual` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否虚拟商品',
  `service_fee_scale` decimal(12,2) DEFAULT '0.00' COMMENT '服务费比例',
  `tax_fee_scale` decimal(12,2) DEFAULT '0.00' COMMENT '税率比例',
  `version` int NOT NULL DEFAULT '0' COMMENT '版本并发控制',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`goods_id`) USING BTREE,
  KEY `idx_goods_spu_goods_name` (`goods_name`) USING BTREE,
  KEY `idx_goods_spu_goods_code` (`goods_code`) USING BTREE,
  KEY `idx_goods_spu_store_id` (`store_id`) USING BTREE,
  KEY `idx_goods_spu_brand_id` (`brand_id`) USING BTREE,
  KEY `idx_goods_spu_category_id3` (`category_id3`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商品SPU信息表';

-- ----------------------------
-- Records of goods_spu
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_stock_log
-- ----------------------------
DROP TABLE IF EXISTS `goods_stock_log`;
CREATE TABLE `goods_stock_log` (
  `stock_log_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '库存记录ID',
  `goods_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品ID',
  `goods_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品名称',
  `sku_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'SKU ID',
  `sku_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'SKU 名称',
  `current_num` int NOT NULL COMMENT '当前修改的数量',
  `before_num` int NOT NULL COMMENT '修改前数量',
  `after_num` int NOT NULL COMMENT '修改后数量',
  `admin_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '管理员ID',
  `admin_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '管理员名称',
  `remark` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  `create_time` datetime(6) NOT NULL COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`stock_log_id`),
  KEY `idx_goods_stock_log_goods_id` (`goods_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='库存日志';

-- ----------------------------
-- Records of goods_stock_log
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_tag
-- ----------------------------
DROP TABLE IF EXISTS `goods_tag`;
CREATE TABLE `goods_tag` (
  `tag_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '标签ID',
  `tag_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '标签名称',
  `tag_logo_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '标签Logo',
  `tag_category_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0' COMMENT '类目ID',
  `tag_category_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '类目名称',
  `sort_value` int NOT NULL COMMENT '排序',
  `is_effect` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否生效',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`tag_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商品标签表';

-- ----------------------------
-- Records of goods_tag
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_tag_category
-- ----------------------------
DROP TABLE IF EXISTS `goods_tag_category`;
CREATE TABLE `goods_tag_category` (
  `tag_category_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '标签类目ID',
  `tag_category_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '类目名称',
  `is_effect` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否生效',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`tag_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商品标签类目表';

-- ----------------------------
-- Records of goods_tag_category
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for goods_tag_correlation
-- ----------------------------
DROP TABLE IF EXISTS `goods_tag_correlation`;
CREATE TABLE `goods_tag_correlation` (
  `goods_tag_correlation_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品标签关联ID',
  `goods_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '商品ID',
  `tag_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '标签ID',
  `is_effect` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否生效',
  `create_time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) COMMENT '创建时间',
  `update_time` datetime(6) NOT NULL ON UPDATE CURRENT_TIMESTAMP(6) COMMENT '更新时间',
  PRIMARY KEY (`goods_tag_correlation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='商品标签关系表';

-- ----------------------------
-- Records of goods_tag_correlation
-- ----------------------------
BEGIN;
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
